import React from "react";

const About = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">About Me</h1>
      <p>
        I’m <strong>Manishwar Repala</strong>, a data analyst with 1 year and 7 months of experience
        in healthcare data solutions at Optum Global Solutions. My work focuses on transforming complex data
        into meaningful insights using SQL Server and Power BI.
      </p>
      <p>
        I specialize in designing and optimizing SQL stored procedures, integrating data from diverse sources,
        and developing interactive dashboards that help stakeholders make data-driven decisions.
      </p>
      <p>
        I’ve worked with tools like SSIS, Power BI, Azure, and Tableau to automate reporting workflows
        and enhance real-time analytics.
      </p>
      <p>
        I’m passionate about data visualization, healthcare technology, and solving real-world problems
        using smart and scalable analytics solutions.
      </p>
      <ul className="list-disc ml-6">
        <li><strong>Tools:</strong> SQL Server, Power BI, SSIS, Tableau</li>
        <li><strong>Cloud:</strong> Azure</li>
        <li><strong>Skills:</strong> SQL, DAX, Data Cleaning, ETL, Visualization</li>
      </ul>
      <p>
        I’ve received a <strong>Special Recognition Award</strong> at Optum (Q2 RNR) for my contributions.
      </p>
    </div>
  );
};

export default About;
