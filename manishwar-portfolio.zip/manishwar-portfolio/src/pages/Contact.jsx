import React from "react";

const Contact = () => {
  return (
    <div className="space-y-6 max-w-xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-700">Contact Me</h1>
      <p>If you'd like to connect with me for collaboration or opportunities, feel free to reach out:</p>

      <div className="space-y-2">
        <p><strong>Email:</strong> <a href="mailto:repalamani5@gmail.com" className="text-blue-600">repalamani5@gmail.com</a></p>
        <p><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/manishwar-repala-678624172/" target="_blank" className="text-blue-600">linkedin.com/in/manishwar-repala-678624172</a></p>
      </div>

      <form className="bg-white shadow-md rounded-2xl p-6 space-y-4">
        <div>
          <label className="block font-medium">Name</label>
          <input type="text" className="w-full p-2 border rounded" placeholder="Your Name" />
        </div>
        <div>
          <label className="block font-medium">Email</label>
          <input type="email" className="w-full p-2 border rounded" placeholder="Your Email" />
        </div>
        <div>
          <label className="block font-medium">Message</label>
          <textarea className="w-full p-2 border rounded" placeholder="Your Message" rows="4"></textarea>
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Send</button>
      </form>
    </div>
  );
};

export default Contact;
