import React from "react";

const Projects = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">Projects</h1>

      <div className="bg-white rounded-2xl p-6 shadow-md">
        <h2 className="text-xl font-semibold text-gray-800">Healthcare Analytics at Optum</h2>
        <p className="text-gray-700 mt-2">
          At Optum Global Solutions, I worked on a healthcare analytics project aimed at improving
          patient care and operational efficiency through data insights. I collaborated with a team of 6
          professionals to develop a suite of real-time dashboards and ETL pipelines.
        </p>
        <ul className="list-disc ml-6 mt-4 text-gray-700">
          <li>Performed data cleaning, transformation, and validation using SQL Server.</li>
          <li>Developed and published Power BI dashboards with interactive visuals for stakeholders.</li>
          <li>Integrated data from SQL, Excel, and APIs to create comprehensive datasets.</li>
          <li>Used DAX to create KPIs and performance metrics.</li>
          <li>Optimized SQL queries and automated reporting processes with SSIS.</li>
          <li>Collaborated with business teams to understand requirements and translate them into intuitive visuals.</li>
          <li>Monitored and resolved Power BI performance bottlenecks.</li>
        </ul>
      </div>
    </div>
  );
};

export default Projects;
