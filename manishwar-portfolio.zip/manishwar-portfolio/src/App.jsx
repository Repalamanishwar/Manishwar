import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import About from "./pages/About";
import Projects from "./pages/Projects";
import Contact from "./pages/Contact";

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 text-gray-900">
        <nav className="bg-blue-600 p-4 shadow-lg">
          <div className="container mx-auto flex justify-between items-center">
            <Link to="/" className="text-white text-2xl font-bold">Manishwar Repala</Link>
            <div>
              <Link to="/about" className="text-white mx-2">About</Link>
              <Link to="/projects" className="text-white mx-2">Projects</Link>
              <Link to="/contact" className="text-white mx-2">Contact</Link>
            </div>
          </div>
        </nav>
        
        <div className="container mx-auto py-10">
          <Routes>
            <Route path="/about" element={<About />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
